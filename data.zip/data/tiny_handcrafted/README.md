NGS Linux Training Dataset
==========================

Contents:
- reference/mini_ref.fasta      : small reference genome
- fastq/sample_R1.fastq         : paired-end read 1
- fastq/sample_R2.fastq         : paired-end read 2
- fastq/broken.fastq            : malformed FASTQ (demo)
- fastq/truncated.fastq         : truncated FASTQ (demo)
- misc/sample.sam               : alignment (text)
- bam/sample.bam                : alignment (binary)
- bam/sample.bam.bai            : BAM index

Designed for:
- Linux command-line training
- FASTA/FASTQ/SAM/BAM exploration
- Debugging demonstrations
- Live alignment walkthroughs
